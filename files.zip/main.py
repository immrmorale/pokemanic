import pygame
import random
import math
import sys
from pokemones import pokemones, movimientos, multiplicador_tipos
from ataques import habilidades, sinergias
from animaciones import direcciones, direccion_vector, AnimadorPokemon, cargar_retrato


def dibujar_esquinas(pantalla, rect, color=(255, 255, 255), margen=10, largo=14, grosor=3):
    r = rect.inflate(margen * 2, margen * 2)
    x1, y1, x2, y2 = r.left, r.top, r.right - 1, r.bottom - 1
    pygame.draw.line(pantalla, color, (x1, y1), (x1 + largo, y1), grosor)
    pygame.draw.line(pantalla, color, (x1, y1), (x1, y1 + largo), grosor)
    pygame.draw.line(pantalla, color, (x2, y1), (x2 - largo, y1), grosor)
    pygame.draw.line(pantalla, color, (x2, y1), (x2, y1 + largo), grosor)
    pygame.draw.line(pantalla, color, (x1, y2), (x1 + largo, y2), grosor)
    pygame.draw.line(pantalla, color, (x1, y2), (x1, y2 - largo), grosor)
    pygame.draw.line(pantalla, color, (x2, y2), (x2 - largo, y2), grosor)
    pygame.draw.line(pantalla, color, (x2, y2), (x2, y2 - largo), grosor)


def main():
    pygame.init()
    W, H = 1000, 600
    ventana = pygame.display.set_mode((W, H))
    pygame.display.set_caption('Pokemanic')
    fuente = pygame.font.Font(None, 24)

    def debug_menu(pokemon):
        scroll = 0
        botones = []
        f_titulo = pygame.font.Font(None, 32)
        while True:
            columnas, bw, bh, bn, sy = 4, 210, 62, 28, 18
            filas = math.ceil(len(pokemones) / columnas)
            max_scroll = max(0, 80 + filas * (bh + bn + sy) - H)

            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return 'salir', pokemon
                if e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_F1):
                    return pokemon, pokemon
                if e.type == pygame.MOUSEWHEEL:
                    scroll = max(0, min(scroll - e.y * 60, max_scroll))
                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    for r, nombre in botones:
                        if r.collidepoint(e.pos):
                            return nombre, nombre

            ventana.fill((20, 20, 20))
            botones = []
            ventana.blit(f_titulo.render('MENU DEBUG', True, 'white'), (25, 15))
            ventana.blit(fuente.render('F1 o ESC para cerrar - rueda del mouse para desplazarte', True, (200, 200, 200)), (25, 45))
            for i, nombre in enumerate(pokemones):
                x = 30 + i % columnas * 240
                y = 85 + i // columnas * (bh + bn + sy) - scroll
                r = pygame.Rect(x, y, bw, bh)
                nr = pygame.Rect(x, y + bh, bw, bn)
                if r.bottom < 65 or nr.top > H:
                    continue
                pygame.draw.rect(ventana, (80, 160, 80) if nombre == pokemon else (200, 200, 200), r)
                pygame.draw.rect(ventana, (50, 50, 50), nr)
                ventana.blit(fuente.render(nombre.replace('_', ' ').title(), True, 'white'), (x + 8, y + 20))
                ventana.blit(fuente.render(nombre, True, 'white'), (x + 8, y + bh + 5))
                botones.append((r, nombre))
            pygame.display.flip()

    def jugar(pokemon):
        pygame.mouse.set_visible(False)
        try: return jugar_partida(pokemon)
        finally: pygame.mouse.set_visible(True)

    def jugar_partida(pokemon):
        ESC = pygame.Rect(0, 0, 1800, 1200)
        PARED = 40
        AREA = ESC.inflate(-80, -80)
        VEL_ENEMIGO = 1
        VEL_P_ENEMIGO = 8
        DIST_P_ENEMIGO = 250
        DETECCION = 350
        DISPARO = 500
        DAÑO_ENEMIGO = 10
        TIPOS_COMBATE = ('lucha', 'hielo', 'volador', 'tierra', 'electrico', 'agua')
        COLORES_TIPO = {'lucha': (220, 70, 70), 'hielo': (130, 220, 255), 'volador': (235, 235, 235), 'tierra': (170, 115, 65), 'electrico': (245, 220, 40), 'agua': (70, 130, 235)}
        COLORES_HAB = dict(COLORES_TIPO, normal=(200, 200, 190), fuego=(240, 120, 40), planta=(90, 190, 80), veneno=(170, 80, 190), psiquico=(240, 100, 170), roca=(180, 160, 100), fantasma=(110, 90, 160), dragon=(110, 80, 230), siniestro=(90, 80, 80), acero=(160, 170, 190))
        CAMBIO_CD, SPRINT_MULT, SPRINT_MAX, ENERGIA_MAX, GASTO_SPRINT, RECARGA_SPRINT = 1500, 1.5, 9.0, 100.0, 0.7, 0.35
        CD_ENEMIGO, CD_JEFE, CD_PIEDRA = 1500, 5000, 2000
        DURACION_PIEDRA = 5000
        CANT_ENEMIGOS, CANT_PIEDRAS = 10, 30
        TAM_JEFE, BALAS_JEFE, PIEDRAS_POR_USO = 160, 24, 4
        DAÑO_JEFE, DAÑO_PIEDRA = 35, 15

        def mover(rect, dx, dy, piedras):
            r = rect.copy(); r.x += dx
            if not any(r.colliderect(piedra) for piedra in piedras): rect.x += dx
            r = rect.copy(); r.y += dy
            if not any(r.colliderect(piedra) for piedra in piedras): rect.y += dy

        def mover_f(o, dx, dy, piedras):
            pos = o.get('pos')
            if pos is None or (round(pos.x), round(pos.y)) != o['rect'].center:
                pos = o['pos'] = pygame.Vector2(o['rect'].center)
            r = o['rect'].copy(); r.centerx = round(pos.x + dx)
            if not any(r.colliderect(p) for p in piedras): pos.x += dx
            r = o['rect'].copy(); r.center = (round(pos.x), round(pos.y + dy))
            if not any(r.colliderect(p) for p in piedras): pos.y += dy
            o['rect'].center = (round(pos.x), round(pos.y))

        def liberar(rect, piedras):
            if not any(rect.colliderect(p) for p in piedras): return
            cx, cy = rect.center
            for dist in range(8, 200, 8):
                for vx, vy in direccion_vector.values():
                    rect.center = (cx + vx * dist, cy + vy * dist)
                    if not any(rect.colliderect(p) for p in piedras) and AREA.contains(rect): return
            rect.center = (cx, cy)

        def crear_piedras():
            piedras = []
            centro = pygame.Rect(ESC.centerx - 250, ESC.centery - 250, 500, 500)
            while len(piedras) < CANT_PIEDRAS:
                piedra = pygame.Rect(random.randint(PARED + 50, ESC.width - PARED - 100), random.randint(PARED + 50, ESC.height - PARED - 100), 50, 50)
                if piedra.colliderect(centro) or any(piedra.colliderect(x.inflate(15, 15)) for x in piedras):
                    continue
                piedras.append(piedra)
            return piedras

        def tipo_combate(datos):
            for tipo in datos.get('tipo', []):
                if tipo in TIPOS_COMBATE: return tipo
            return None

        def daño_con_tipo(daño, ataque_tipo, defensa_tipo):
            if daño <= 0: return 0
            mult = multiplicador_tipos(ataque_tipo, defensa_tipo)
            return 0 if mult == 0 else max(1, round(daño * mult))

        def crear_puertas():
            return [
                pygame.Rect(ESC.centerx - 30, 0, 60, PARED),
                pygame.Rect(ESC.centerx - 30, ESC.bottom - PARED, 60, PARED),
                pygame.Rect(0, ESC.centery - 30, PARED, 60),
                pygame.Rect(ESC.right - PARED, ESC.centery - 30, PARED, 60)
            ]

        def stats_pokemon(nombre):
            datos = pokemones[nombre]
            s = datos.get('estadisticas_juego') or {}
            vida = s.get('vida', datos.get('vida', datos.get('vida_base', 100)))
            velocidad = s.get('velocidad', datos.get('velocidad_movimiento', datos.get('velocidad', 5)))
            tamaño = s.get('tamaño', datos.get('tamaño', 40))
            hitbox = s.get('hitbox_ancho', s.get('hitbox', datos.get('hitbox', tamaño)))
            hitbox_alto = s.get('hitbox_alto', hitbox)
            try: vida = max(1, int(float(vida)))
            except (TypeError, ValueError): vida = 100
            try: velocidad = max(0.1, float(velocidad))
            except (TypeError, ValueError): velocidad = 5.0
            try: tamaño = max(1, int(float(tamaño)))
            except (TypeError, ValueError): tamaño = 40
            try: hitbox = max(1, int(float(hitbox))); hitbox_alto = max(1, int(float(hitbox_alto)))
            except (TypeError, ValueError): hitbox = hitbox_alto = tamaño
            return datos, vida, velocidad, tamaño, (hitbox, hitbox_alto)

        def crear_jugador(nombre, centro):
            nombre = nombre if nombre in pokemones else 'pikachu'
            datos, vida, velocidad, tamaño, hitbox = stats_pokemon(nombre)
            rect = pygame.Rect(0, 0, hitbox[0], hitbox[1])
            rect.center = centro
            s = datos.get('estadisticas_juego') or {}
            return {'nombre': nombre, 'datos': datos, 'pos': pygame.Vector2(rect.center),
                    'cooldown_mult': float(s.get('cooldown_mult', 1.0)), 'cd_hab_mult': float(s.get('cooldown_hab_mult', 1.0)),
                    'daño_mult': float(s.get('daño_mult', 1.0)), 'sinergia': float(s.get('sinergia', 0.0)), 'bonus_equipo': 1.0,
                    'max_vida': vida, 'vida': float(vida), 'velocidad': velocidad, 'vel_actual': velocidad, 'tamaño': tamaño,
                    'hitbox': hitbox, 'rect': rect, 'direccion': 'sur', 'moviendose': False, 'ultimo_golpe': -1000,
                    'ultimo_proyectil': -1000, 'atacando': False, 'llave': False,
                    'energia': ENERGIA_MAX, 'agotado': False, 'sprint': False, 'ultimo_sprint': -1000,
                    'ultimo_hab': [-100000, -100000], 'buff': None, 'escudo_hasta': 0, 'inmovil_hasta': 0, 'cura': None, 'embestida': None,
                    'aim': None, 'buff_sin': None, 'poder_apoyo': float(s.get('poder_apoyo', 1.0)),
                    'ultimo_sin': pygame.time.get_ticks() - int(sinergias.get(datos.get('apoyo'), {}).get('enfriamiento', 0) * 0.5),
                    'animador': AnimadorPokemon(nombre, rect, tamaño)}

        def armar_equipo(principal):
            equipo = [principal]
            for nombre in ('sneasel', 'raichu', 'pikachu', 'lapras'):
                if len(equipo) < 3 and nombre in pokemones and nombre not in equipo and pokemones[nombre].get('jugable'):
                    equipo.append(nombre)
            return equipo

        def reubicar_equipo(equipo):
            for p in equipo:
                p['rect'].center = ESC.center
                p['pos'] = pygame.Vector2(p['rect'].center)
                p.update({'direccion': 'sur', 'moviendose': False, 'atacando': False, 'llave': False,
                          'ultimo_golpe': -1000, 'ultimo_proyectil': -1000, 'embestida': None, 'cura': None, 'escudo_hasta': 0, 'inmovil_hasta': 0})

        def cambiar_activo(equipo, activo, nuevo, piedras):
            a, n = equipo[activo], equipo[nuevo]
            n['rect'].center = a['rect'].center
            liberar(n['rect'], piedras)
            n['pos'] = pygame.Vector2(n['rect'].center)
            n['direccion'] = a['direccion']; n['aim'] = a['aim']; n['llave'] = a['llave']
            a['llave'] = False; a['moviendose'] = False; a['atacando'] = False; a['embestida'] = None; a['cura'] = None; a['inmovil_hasta'] = 0
            return nuevo

        def camara(j):
            return max(0, min(j['rect'].centerx - W // 2, ESC.width - W)), max(0, min(j['rect'].centery - H // 2, ESC.height - H))

        def direccion_8(vx, vy):
            return ('este', 'sureste', 'sur', 'suroeste', 'oeste', 'noroeste', 'norte', 'noreste')[round(math.degrees(math.atan2(vy, vx)) / 45) % 8]

        def vec_apunte(j):
            if j['aim']: return j['aim']
            vx, vy = direccion_vector[j['direccion']]
            n = math.hypot(vx, vy)
            return vx / n, vy / n

        def mult_buff(j, clave):
            ahora = pygame.time.get_ticks()
            mult = 1.0
            for campo in ('buff', 'buff_sin'):
                b = j[campo]
                if not b: continue
                if ahora >= b['hasta']: j[campo] = None
                else: mult *= b['mejoras'].get(clave, 1.0)
            return mult

        def mult_daño(j):
            return j['daño_mult'] * j['bonus_equipo'] * mult_buff(j, 'daño')

        def mult_cd(j):
            return j['cooldown_mult'] * mult_buff(j, 'cooldown')

        def mover_jugador(j, piedras):
            ahora = pygame.time.get_ticks()
            t = pygame.key.get_pressed()
            dx, dy = t[pygame.K_d] - t[pygame.K_a], t[pygame.K_s] - t[pygame.K_w]
            j['moviendose'] = bool(dx or dy) and ahora >= j['inmovil_hasta'] and not j['embestida']
            if j['agotado'] and j['energia'] >= 25: j['agotado'] = False
            j['sprint'] = bool(t[pygame.K_LCTRL] or t[pygame.K_RCTRL]) and j['moviendose'] and j['energia'] > 0 and not j['agotado']
            if j['sprint']:
                j['energia'] = max(0.0, j['energia'] - GASTO_SPRINT); j['ultimo_sprint'] = ahora
                if j['energia'] <= 0: j['agotado'] = True
            elif ahora - j['ultimo_sprint'] > 600:
                j['energia'] = min(ENERGIA_MAX, j['energia'] + RECARGA_SPRINT)
            vel = j['velocidad'] * mult_buff(j, 'velocidad')
            if j['sprint']: vel = min(vel * SPRINT_MULT, SPRINT_MAX)
            j['vel_actual'] = vel
            if not j['moviendose']: return
            dirs = {(1,-1):'noreste',(1,1):'sureste',(-1,-1):'noroeste',(-1,1):'suroeste',(1,0):'este',(-1,0):'oeste',(0,-1):'norte',(0,1):'sur'}
            if not j['aim']: j['direccion'] = dirs[(dx, dy)]
            n = math.hypot(dx, dy)
            mover_f(j, dx / n * vel, 0, piedras)
            mover_f(j, 0, dy / n * vel, piedras)
            j['rect'].clamp_ip(AREA)

        def ataque(j, tipo):
            a = (j['datos'].get('ataques_estadisticas') or {}).get(tipo)
            if a is not None: return a
            nombre = j['datos'].get('ataque_cuerpo' if tipo == 'cuerpo' else 'ataque_proyectil')
            return movimientos.get(nombre)

        def atacar_cuerpo(j, objetivos):
            datos = ataque(j, 'cuerpo')
            if not datos: return
            datos = dict(datos)
            datos['tipo'] = datos.get('tipo') or datos.get('tipo_ataque') or tipo_combate(j['datos'])
            ahora = pygame.time.get_ticks()
            try: enfriamiento = max(0, int(float(datos.get('enfriamiento', 300))))
            except (TypeError, ValueError): enfriamiento = 300
            enfriamiento = int(enfriamiento * mult_cd(j))
            datos['daño'] = float(datos.get('daño', 0)) * mult_daño(j)
            if j['atacando'] or j['embestida'] or ahora < j['inmovil_hasta'] or ahora - j['ultimo_golpe'] < enfriamiento: return
            j['ultimo_golpe'] = ahora; j['atacando'] = True
            anim = j['animador'].buscar_ataque()
            if anim: j['animador'].cambiar(anim, direcciones.index(j['direccion']), False)
            vx, vy = vec_apunte(j)
            try: d = max(1, int(float(datos.get('distancia', 50))))
            except (TypeError, ValueError): d = 50
            try: area = max(1, int(float(datos.get('area', 20))))
            except (TypeError, ValueError): area = 20
            r = pygame.Rect(0, 0, max(1, int(abs(vx) * d + abs(vy) * area * 2)), max(1, int(abs(vy) * d + abs(vx) * area * 2))); r.center = (round(j['rect'].centerx + vx * d / 2), round(j['rect'].centery + vy * d / 2))
            for objetivo in objetivos:
                if objetivo['vida'] > 0 and r.colliderect(objetivo['rect']):
                    recibir_ataque(objetivo, datos, (vx, vy))

        def atacar_proyectil(j, proyectiles):
            datos = ataque(j, 'proyectil')
            if not datos: return
            datos = dict(datos)
            datos['tipo'] = datos.get('tipo') or datos.get('tipo_ataque') or tipo_combate(j['datos'])
            ahora = pygame.time.get_ticks()
            try: enfriamiento = max(0, int(float(datos.get('enfriamiento', 300))))
            except (TypeError, ValueError): enfriamiento = 300
            enfriamiento = int(enfriamiento * mult_cd(j))
            datos['daño'] = float(datos.get('daño', 0)) * mult_daño(j)
            if j['atacando'] or j['embestida'] or ahora < j['inmovil_hasta'] or ahora - j['ultimo_proyectil'] < enfriamiento: return
            j['ultimo_proyectil'] = ahora
            vx, vy = vec_apunte(j)
            d = max(20, max(j['hitbox']) // 2)
            x, y = j['rect'].centerx + vx * d, j['rect'].centery + vy * d
            try: area = max(1, int(float(datos.get('area', 8))))
            except (TypeError, ValueError): area = 8
            tamaño = max(2, area * 2)
            proyectiles.append({'x': float(x), 'y': float(y), 'direccion': j['direccion'], 'vec': (vx, vy), 'datos': datos, 'rect': pygame.Rect(0,0,tamaño,tamaño), 'distancia': 0, 'activo': True, 'golpeados': []})

        def objetivos_nivel(nivel):
            return nivel['enemigos'][:] + ([nivel['jefe']] if nivel['jefe'] else [])

        def usar_habilidad(j, indice, nivel):
            claves = j['datos'].get('habilidades') or []
            if indice >= len(claves) or claves[indice] not in habilidades: return
            h = habilidades[claves[indice]]
            ahora = pygame.time.get_ticks()
            if j['embestida'] or ahora < j['inmovil_hasta']: return
            if ahora - j['ultimo_hab'][indice] < h['enfriamiento'] * j['cd_hab_mult'] * mult_buff(j, 'cooldown'): return
            j['ultimo_hab'][indice] = ahora
            modo = h['modo']
            datos = dict(h); datos['daño'] = float(h.get('daño', 0)) * mult_daño(j)
            vx, vy = vec_apunte(j)
            if modo == 'embestida':
                j['embestida'] = {'vx': vx, 'vy': vy, 'restante': float(h['distancia']), 'vel': float(h['velocidad']), 'datos': datos, 'golpeados': []}
                j['atacando'] = True
                anim = j['animador'].buscar_ataque()
                if anim: j['animador'].cambiar(anim, direcciones.index(j['direccion']), False)
            elif modo == 'proyectil':
                d = max(20, max(j['hitbox']) // 2)
                x, y = j['rect'].centerx + vx * d, j['rect'].centery + vy * d
                tamaño = max(2, int(h['area']) * 2)
                cantidad = h.get('cantidad', 1)
                base = math.atan2(vy, vx)
                for i in range(cantidad):
                    p = {'x': float(x), 'y': float(y), 'direccion': j['direccion'], 'datos': datos, 'rect': pygame.Rect(0, 0, tamaño, tamaño), 'distancia': 0, 'activo': True, 'golpeados': []}
                    ang = base + (math.radians(h['abanico']) * (i / (cantidad - 1) - 0.5) if cantidad > 1 else 0)
                    p['vec'] = (math.cos(ang), math.sin(ang))
                    nivel['proyectiles_pokemon'].append(p)
            elif modo == 'area':
                centro = j['rect'].center
                for o in objetivos_nivel(nivel):
                    if o['vida'] > 0 and pygame.Vector2(o['rect'].center).distance_to(centro) <= h['area'] + max(o['rect'].size) / 2:
                        recibir_ataque(o, datos, None)
                nivel['efectos'].append({'x': centro[0], 'y': centro[1], 'radio': h['area'], 'inicio': ahora, 'duracion': 350, 'color': COLORES_HAB.get(h['tipo'], (255, 255, 255))})
            elif modo == 'buff':
                j['buff'] = {'hasta': ahora + h['duracion'], 'mejoras': h['mejoras']}
            elif modo == 'curar':
                j['cura'] = {'hasta': ahora + h['duracion'], 'por_frame': j['max_vida'] * h['cura'] / max(1.0, h['duracion'] * 0.06)}
                if h.get('dormir'): j['inmovil_hasta'] = ahora + h['duracion']
            elif modo == 'escudo':
                j['escudo_hasta'] = ahora + h['duracion']

        def actualizar_estados_jugador(j, nivel):
            ahora = pygame.time.get_ticks()
            c = j['cura']
            if c:
                if ahora >= c['hasta']: j['cura'] = None
                else: j['vida'] = min(j['max_vida'], j['vida'] + c['por_frame'])
            e = j['embestida']
            if not e: return
            antes = j['rect'].center
            paso = min(e['vel'], e['restante'])
            mover_f(j, e['vx'] * paso, 0, nivel['piedras']); mover_f(j, 0, e['vy'] * paso, nivel['piedras'])
            j['rect'].clamp_ip(AREA)
            e['restante'] -= paso
            extra = int(e['datos'].get('area', 0)) * 2
            zona = j['rect'].inflate(extra, extra)
            for o in objetivos_nivel(nivel):
                if o['vida'] > 0 and id(o) not in e['golpeados'] and zona.colliderect(o['rect']):
                    recibir_ataque(o, e['datos'], (e['vx'], e['vy'])); e['golpeados'].append(id(o))
            if e['restante'] <= 0 or j['rect'].center == antes: j['embestida'] = None

        def usar_sinergia(equipo, activo, indice, nivel):
            bancas = [i for i in range(len(equipo)) if i != activo]
            if indice >= len(bancas): return
            p = equipo[bancas[indice]]
            s = sinergias.get(p['datos'].get('apoyo'))
            ahora = pygame.time.get_ticks()
            if not s or p['vida'] <= 0 or ahora - p['ultimo_sin'] < s['enfriamiento']: return
            p['ultimo_sin'] = ahora
            j = equipo[activo]; f = p['poder_apoyo']; modo = s['modo']
            centro = j['rect'].center
            color = COLORES_HAB.get(s['tipo'], (255, 255, 255))
            datos = dict(s); datos['daño'] = float(s.get('daño', 0)) * f * p['daño_mult']
            objetivos = [o for o in objetivos_nivel(nivel) if o['vida'] > 0]
            objetivos.sort(key=lambda o: pygame.Vector2(o['rect'].center).distance_to(centro))
            efectos = nivel['efectos']
            if modo == 'rayos':
                for o in objetivos[:max(1, round(s['cantidad'] * f))]:
                    recibir_ataque(o, datos, None)
                    efectos.append({'x': o['rect'].centerx, 'y': o['rect'].centery, 'radio': 30, 'inicio': ahora, 'duracion': 400, 'color': color, 'linea': True})
            elif modo == 'onda':
                for o in objetivos:
                    if pygame.Vector2(o['rect'].center).distance_to(centro) <= s['area'] + max(o['rect'].size) / 2: recibir_ataque(o, datos, None)
                efectos.append({'x': centro[0], 'y': centro[1], 'radio': s['area'], 'inicio': ahora, 'duracion': 500, 'color': color})
            elif modo == 'desaparecer':
                for o in [o for o in objetivos if o is not nivel['jefe']][:max(1, round(s['cantidad'] * f))]:
                    o['vida'] = 0
                    efectos.append({'x': o['rect'].centerx, 'y': o['rect'].centery, 'radio': 40, 'inicio': ahora, 'duracion': 500, 'color': color})
            elif modo == 'curar_equipo':
                for m in equipo:
                    if m['vida'] > 0: m['vida'] = min(m['max_vida'], m['vida'] + m['max_vida'] * s['cura'] * f)
                efectos.append({'x': centro[0], 'y': centro[1], 'radio': 70, 'inicio': ahora, 'duracion': 600, 'color': color})
            elif modo == 'buff_equipo':
                mejoras = {k: 1 + (v - 1) * f for k, v in s['mejoras'].items()}
                for m in equipo: m['buff_sin'] = {'hasta': ahora + s['duracion'], 'mejoras': mejoras}
                efectos.append({'x': centro[0], 'y': centro[1], 'radio': 70, 'inicio': ahora, 'duracion': 600, 'color': color})
            elif modo == 'escudo_equipo':
                for m in equipo: m['escudo_hasta'] = ahora + int(s['duracion'] * f)
                efectos.append({'x': centro[0], 'y': centro[1], 'radio': 70, 'inicio': ahora, 'duracion': 600, 'color': color})
            elif modo == 'efecto_sala':
                for o in objetivos: recibir_ataque(o, datos, None)
                efectos.append({'x': centro[0], 'y': centro[1], 'radio': 500, 'inicio': ahora, 'duracion': 600, 'color': color})
            elif modo == 'anillo':
                n = s['cantidad']; tamaño = max(2, int(s['area']) * 2)
                for i in range(n):
                    ang = 2 * math.pi * i / n; vec = (math.cos(ang), math.sin(ang))
                    nivel['proyectiles_pokemon'].append({'x': float(centro[0]), 'y': float(centro[1]), 'direccion': direccion_8(*vec), 'vec': vec, 'datos': datos, 'rect': pygame.Rect(0, 0, tamaño, tamaño), 'distancia': 0, 'activo': True, 'golpeados': []})

        def actualizar_jugador(j):
            a = j['animador']; ahora = pygame.time.get_ticks()
            if j['atacando'] and a.esta_terminada(): j['atacando'] = False
            d = direcciones.index(j['direccion'])
            if ahora < j['inmovil_hasta']:
                a.escala_tiempo = 1.0
                if not a.cambiar('sleep', d, True): a.cambiar('idle', d, True)
            elif j['atacando']:
                anim = a.buscar_ataque()
                a.escala_tiempo = max(0.7, min(1.4, mult_cd(j)))
                if anim: a.cambiar(anim, d, False)
                else: j['atacando'] = False
            else:
                a.escala_tiempo = max(0.6, min(1.5, 5.0 / max(1.0, j['vel_actual']))) if j['moviendose'] else 1.0
                if not a.cambiar('walk' if j['moviendose'] else 'idle', d, True): a.cambiar('idle', d, True)
            a.actualizar()

        def dañar_jugador(j, daño, tipo=None):
            if pygame.time.get_ticks() < j['escudo_hasta']: return
            try: daño = max(0, float(daño))
            except (TypeError, ValueError): daño = 0
            if tipo: daño *= multiplicador_tipos(tipo, j['datos'].get('tipo', []))
            j['vida'] = max(0, j['vida'] - daño * mult_buff(j, 'resistencia'))

        def recibir_ataque(obj, datos, direccion=None):
            ataque_tipo = datos.get('tipo') or datos.get('tipo_ataque')
            defensa_tipo = obj.get('tipo')
            try: daño_base = float(datos.get('daño', 0))
            except (TypeError, ValueError): daño_base = 0
            daño = daño_con_tipo(daño_base, ataque_tipo, defensa_tipo)
            obj['vida'] = max(0, obj['vida'] - daño)
            efecto = datos.get('efecto'); ahora = pygame.time.get_ticks()
            try: probabilidad = max(0, min(100, float(efecto.get('probabilidad', 100)))) if efecto else 0
            except (TypeError, ValueError): probabilidad = 100 if efecto else 0
            if efecto and random.randint(1, 100) <= probabilidad:
                try: duracion = max(1, int(float(efecto.get('duracion', 1000))))
                except (TypeError, ValueError): duracion = 1000
                obj['estado'] = efecto.get('tipo'); obj['estado_hasta'] = ahora + duracion; obj['proximo_estado'] = ahora + 700
            try: retroceso = float(datos.get('retroceso', 0))
            except (TypeError, ValueError): retroceso = 0
            if retroceso and direccion:
                vx, vy = direccion if isinstance(direccion, tuple) else direccion_vector.get(direccion, (0, 0))
                obj['rect'].x += vx * retroceso; obj['rect'].y += vy * retroceso; obj['rect'].clamp_ip(AREA)

        def crear_enemigo(piedras):
            while True:
                tamaño, vida = 50, 100
                r = pygame.Rect(random.randint(PARED+10, ESC.width-PARED-tamaño-10), random.randint(PARED+10, ESC.height-PARED-tamaño-10), tamaño, tamaño)
                if pygame.Vector2(r.center).distance_to(ESC.center) <= 300 or any(r.colliderect(piedra) for piedra in piedras):
                    continue
                ahora = pygame.time.get_ticks()
                tipo = random.choice(TIPOS_COMBATE)
                return {'tipo': tipo, 'rect': r, 'vida': vida, 'max_vida': vida, 'daño': DAÑO_ENEMIGO, 'color': COLORES_TIPO[tipo], 'ultimo_golpe': 0,
                        'quieto_hasta': 0, 'cambio': ahora, 'dx': random.choice([-1,0,1]), 'dy': random.choice([-1,0,1]), 'estado': None, 'estado_hasta': 0, 'proximo_estado': 0}

        def actualizar_estado(e):
            ahora = pygame.time.get_ticks()
            if e['estado'] == 'quemar' and e['proximo_estado'] <= ahora < e['estado_hasta']:
                e['vida'] = max(0, e['vida'] - 3); e['proximo_estado'] = ahora + 700
            if ahora >= e['estado_hasta']: e['estado'] = None

        def crear_proyectil(x, y, dx, dy, daño, jefe=False, tipo=None):
            return {'x': float(x), 'y': float(y), 'dx': dx, 'dy': dy, 'daño': daño, 'jefe': jefe, 'tipo': tipo, 'distancia': 0, 'activo': True, 'rect': pygame.Rect(int(x)-8, int(y)-8, 16, 16)}

        def actualizar_proyectil(proyectil, j, piedras):
            proyectil['x'] += proyectil['dx'] * VEL_P_ENEMIGO; proyectil['y'] += proyectil['dy'] * VEL_P_ENEMIGO; proyectil['distancia'] += VEL_P_ENEMIGO
            proyectil['rect'].center = round(proyectil['x']), round(proyectil['y'])
            if proyectil['distancia'] >= DIST_P_ENEMIGO or not ESC.colliderect(proyectil['rect']) or any(proyectil['rect'].colliderect(x) for x in piedras):
                proyectil['activo'] = False; return
            if proyectil['rect'].colliderect(j['rect']): dañar_jugador(j, proyectil['daño'], proyectil.get('tipo')); proyectil['activo'] = False

        def actualizar_proyectil_pokemon(proyectil, objetivos, piedras):
            vx, vy = proyectil.get('vec') or direccion_vector[proyectil['direccion']]
            try: paso = max(0.1, float(proyectil['datos'].get('velocidad', 8)))
            except (TypeError, ValueError): paso = 8.0
            proyectil['x'] += vx * paso; proyectil['y'] += vy * paso; proyectil['distancia'] += paso; proyectil['rect'].center = round(proyectil['x']), round(proyectil['y'])
            try: distancia_maxima = max(1.0, float(proyectil['datos'].get('distancia', 250)))
            except (TypeError, ValueError): distancia_maxima = 250.0
            if proyectil['distancia'] >= distancia_maxima or not ESC.colliderect(proyectil['rect']) or any(proyectil['rect'].colliderect(x) for x in piedras):
                proyectil['activo'] = False; return
            for o in objetivos:
                if o['vida'] <= 0 or o in proyectil['golpeados']: continue
                try: a = max(0, int(float(proyectil['datos'].get('area', 0))))
                except (TypeError, ValueError): a = 0
                zona = o['rect'].inflate(a * 2, a * 2)
                if zona.colliderect(proyectil['rect']):
                    recibir_ataque(o, proyectil['datos'], proyectil.get('vec') or proyectil['direccion']); proyectil['golpeados'].append(o)
                    if not proyectil['datos'].get('atraviesa', False): proyectil['activo'] = False; return

        def actualizar_enemigo(e, j, piedras, proyectiles):
            ahora = pygame.time.get_ticks()
            if ahora < e['quieto_hasta'] or e['estado'] == 'paralizar':
                return
            distancia = pygame.Vector2(e['rect'].center).distance_to(j['rect'].center)
            if distancia <= DETECCION:
                ex = (j['rect'].centerx > e['rect'].centerx) - (j['rect'].centerx < e['rect'].centerx)
                ey = (j['rect'].centery > e['rect'].centery) - (j['rect'].centery < e['rect'].centery)
                vel = 0.45 if e['estado'] == 'ralentizar' else VEL_ENEMIGO
                mover_f(e, ex*vel, 0, piedras)
                mover_f(e, 0, ey*vel, piedras)
            else:
                if ahora >= e['cambio']:
                    e['dx'], e['dy'] = random.choice([-1,0,1]), random.choice([-1,0,1])
                    e['cambio'] = ahora + random.randint(500,1500)
                mover(e['rect'], e['dx']*VEL_ENEMIGO, 0, piedras)
                mover(e['rect'], 0, e['dy']*VEL_ENEMIGO, piedras)
            e['rect'].clamp_ip(AREA)
            if e['rect'].colliderect(j['rect']) and ahora-e['ultimo_golpe'] >= 500:
                dañar_jugador(j, e['daño'], e['tipo'])
                e['ultimo_golpe'] = ahora
                e['quieto_hasta'] = ahora+500
                v = pygame.Vector2(e['rect'].center) - pygame.Vector2(j['rect'].center)
                if v.length():
                    v.normalize_ip()
                    e['rect'].x += v.x * 50
                    e['rect'].y += v.y * 50
                    e['rect'].clamp_ip(AREA)

        def crear_jefe(piedras):
            while True:
                r = pygame.Rect(random.randint(PARED+100, ESC.width-PARED-TAM_JEFE-100), random.randint(PARED+100, ESC.height-PARED-TAM_JEFE-100), TAM_JEFE, TAM_JEFE)
                if pygame.Vector2(r.center).distance_to(ESC.center) <= 400 or any(r.colliderect(piedra.inflate(20,20)) for piedra in piedras): continue
                ahora = pygame.time.get_ticks()
                tipo = random.choice(TIPOS_COMBATE)
                return {'rect': r, 'vida': 500, 'max_vida': 500, 'daño': DAÑO_JEFE, 'tipo': tipo, 'color': COLORES_TIPO[tipo], 'ultimo_golpe': 0, 'ultimo_disparo': ahora, 'ultimo_poder': ahora,
                        'cambio': ahora, 'dx': random.choice([-1,0,1]), 'dy': random.choice([-1,0,1])}

        def crear_piedras_verdes(jefe):
            nuevas = []
            for _ in range(PIEDRAS_POR_USO):
                for _ in range(20):
                    a, d = random.uniform(0, math.tau), random.randint(120,400)
                    r = pygame.Rect(int(jefe['rect'].centerx + math.cos(a)*d), int(jefe['rect'].centery + math.sin(a)*d), 45, 45)
                    if not AREA.contains(r) or r.colliderect(jefe['rect']) or any(r.colliderect(x['rect']) for x in nuevas): continue
                    nuevas.append({'rect': r, 'tiempo': pygame.time.get_ticks(), 'daño': 0}); break
            return nuevas

        def actualizar_jefe(jefe, j, piedras, proyectiles, verdes):
            ahora = pygame.time.get_ticks()
            d = pygame.Vector2(jefe['rect'].center).distance_to(j['rect'].center)
            if d <= DETECCION + 150:
                ex = (j['rect'].centerx > jefe['rect'].centerx) - (j['rect'].centerx < jefe['rect'].centerx)
                ey = (j['rect'].centery > jefe['rect'].centery) - (j['rect'].centery < jefe['rect'].centery)
                mover(jefe['rect'], ex, 0, piedras); mover(jefe['rect'], 0, ey, piedras)
            else:
                if ahora >= jefe['cambio']:
                    jefe['dx'], jefe['dy'] = random.choice([-1,0,1]), random.choice([-1,0,1]); jefe['cambio'] = ahora + random.randint(500,1500)
                mover(jefe['rect'], jefe['dx'], 0, piedras); mover(jefe['rect'], 0, jefe['dy'], piedras)
            jefe['rect'].clamp_ip(AREA)
            if ahora - jefe['ultimo_disparo'] >= CD_JEFE:
                for i in range(BALAS_JEFE):
                    a = i * math.tau / BALAS_JEFE; dx, dy = math.cos(a), math.sin(a); r = TAM_JEFE//2+10
                    proyectiles.append(crear_proyectil(jefe['rect'].centerx+dx*r, jefe['rect'].centery+dy*r, dx, dy, 25, True, jefe['tipo']))
                jefe['ultimo_disparo'] = ahora
            if ahora - jefe['ultimo_poder'] >= CD_PIEDRA:
                verdes.extend(crear_piedras_verdes(jefe)); jefe['ultimo_poder'] = ahora
            if jefe['rect'].colliderect(j['rect']) and ahora-jefe['ultimo_golpe'] >= 700:
                dañar_jugador(j, jefe['daño'], jefe['tipo']); jefe['ultimo_golpe'] = ahora

        def menu_niveles(nivel_actual):
            seleccionado = nivel_actual
            reloj_debug = pygame.time.Clock()
            f_titulo = pygame.font.Font(None, 34)
            f_texto = pygame.font.Font(None, 24)
            while True:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        return 'salir'
                    if e.type == pygame.KEYDOWN:
                        if e.key in (pygame.K_ESCAPE, pygame.K_F2):
                            return seleccionado
                        if e.key == pygame.K_UP: seleccionado = max(0, seleccionado - 1)
                        if e.key == pygame.K_DOWN: seleccionado = min(20, seleccionado + 1)
                        if e.key == pygame.K_LEFT: seleccionado = max(0, seleccionado - 11)
                        if e.key == pygame.K_RIGHT: seleccionado = min(20, seleccionado + 11)
                        if e.key == pygame.K_RETURN:
                            return seleccionado
                ventana.fill((18,18,18))
                ventana.blit(f_titulo.render('DEBUG DE NIVELES', True, 'white'), (30, 25))
                ventana.blit(f_texto.render('F2 o ESC para volver - Flechas para elegir - ENTER para aplicar', True, (200,200,200)), (30, 60))
                for i in range(21):
                    x, y = 140 + (i // 11) * 380, 110 + (i % 11) * 40
                    pygame.draw.rect(ventana, (80,180,80) if i == seleccionado else (100,100,100), (x, y, 340, 32))
                    ventana.blit(f_texto.render('Nivel ' + str(i + 1), True, 'white'), (x + 130, y + 8))
                pygame.display.flip(); reloj_debug.tick(60)

        def confirmar_salida():
            reloj_salida = pygame.time.Clock()
            while True:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        return True
                    if e.type == pygame.KEYDOWN:
                        if e.key in (pygame.K_ESCAPE, pygame.K_n):
                            return False
                        if e.key in (pygame.K_RETURN, pygame.K_y):
                            return True
                fondo = pygame.Surface((W,H), pygame.SRCALPHA)
                fondo.fill((0,0,0,150))
                ventana.blit(fondo, (0,0))
                r = pygame.Rect(250, 205, 500, 190)
                pygame.draw.rect(ventana, (35,35,35), r)
                pygame.draw.rect(ventana, (220,220,220), r, 2)
                f = pygame.font.Font(None, 32)
                ventana.blit(f.render('¿Seguro que quieres salir?', True, 'white'), (315,245))
                ventana.blit(f.render('ENTER / Y: Sí    ESC / N: No', True, (210,210,210)), (315,300))
                pygame.display.flip(); reloj_salida.tick(60)

        def crear_nivel(numero):
            piedras = crear_piedras()
            jefe = crear_jefe(piedras) if numero >= 2 and (numero + 1) % 3 == 0 else None
            return {'piedras': piedras, 'enemigos': [] if jefe else [crear_enemigo(piedras) for _ in range(CANT_ENEMIGOS)], 'jefe': jefe,
                    'proyectiles_pokemon': [], 'proyectiles_enemigos': [], 'verdes': [], 'puertas': crear_puertas(), 'llave': None, 'completado': False, 'efectos': []}

        def actualizar_nivel(nivel, j):
            ahora = pygame.time.get_ticks(); piedras = nivel['piedras']; enemigos = nivel['enemigos']; jefe = nivel['jefe']
            nivel['efectos'] = [ef for ef in nivel['efectos'] if ahora - ef['inicio'] < ef['duracion']]
            mover_jugador(j, piedras); actualizar_estados_jugador(j, nivel); actualizar_jugador(j)
            objetivos = enemigos[:] + ([jefe] if jefe else [])
            for proyectil in nivel['proyectiles_pokemon']: actualizar_proyectil_pokemon(proyectil, objetivos, piedras)
            nivel['proyectiles_pokemon'] = [proyectil for proyectil in nivel['proyectiles_pokemon'] if proyectil['activo']]
            for e in enemigos:
                actualizar_estado(e)
                if e['vida'] > 0: actualizar_enemigo(e, j, piedras, nivel['proyectiles_enemigos'])
            nivel['enemigos'] = [e for e in enemigos if e['vida'] > 0]
            if jefe:
                actualizar_jefe(jefe, j, piedras, nivel['proyectiles_enemigos'], nivel['verdes'])
                if jefe['vida'] <= 0: nivel['jefe'] = None
            for proyectil in nivel['proyectiles_enemigos']: actualizar_proyectil(proyectil, j, piedras)
            nivel['proyectiles_enemigos'] = [proyectil for proyectil in nivel['proyectiles_enemigos'] if proyectil['activo']]
            for piedra_verde in nivel['verdes'][:]:
                if ahora - piedra_verde['tiempo'] >= DURACION_PIEDRA: nivel['verdes'].remove(piedra_verde); continue
                if j['rect'].colliderect(piedra_verde['rect']) and ahora-piedra_verde['daño'] >= 500: dañar_jugador(j, DAÑO_PIEDRA); piedra_verde['daño'] = ahora
            derrotados = not nivel['enemigos'] and nivel['jefe'] is None
            nivel['completado'] = derrotados
            if derrotados and nivel['llave'] is None and not j['llave']:
                nivel['llave'] = pygame.Rect(ESC.centerx-15, ESC.centery-15, 30, 30)
            if nivel['llave'] and j['rect'].colliderect(nivel['llave']): j['llave'] = True; nivel['llave'] = None
            if j['vida'] <= 0: return 'muerte'
            if j['llave'] and any(j['rect'].colliderect(puerta.inflate(20,20)) for puerta in nivel['puertas']):
                return 'siguiente'
            if not j['llave']:
                for puerta in nivel['puertas']:
                    if j['rect'].colliderect(puerta.inflate(8, 8)):
                        if j['rect'].centerx < puerta.left: j['rect'].right = puerta.left
                        elif j['rect'].centerx > puerta.right: j['rect'].left = puerta.right
                        elif j['rect'].centery < puerta.top: j['rect'].bottom = puerta.top
                        else: j['rect'].top = puerta.bottom

        def dibujar_rect(rect, cx, cy, color, forma='rect'):
            r = pygame.Rect(rect.x-cx, rect.y-cy, rect.width, rect.height)
            (pygame.draw.ellipse if forma == 'ellipse' else pygame.draw.rect)(ventana, color, r)

        def dibujar_jugador(j, cx, cy):
            if j['animador'].dibujar(ventana, (-cx, -cy)): return
            r = pygame.Rect(0,0,j['tamaño'],j['tamaño']); r.center = j['rect'].centerx-cx, j['rect'].centery-cy; pygame.draw.rect(ventana, (255,50,255), r)

        def barra(rect, vida, max_vida, alto=5):
            pygame.draw.rect(ventana, (80,0,0), rect)
            pygame.draw.rect(ventana, (0,200,0), (rect[0], rect[1], int(max(0, vida*rect[2]//max(1,max_vida))), rect[3]))

        f_hud = pygame.font.Font(None, 17)
        f_hud_g = pygame.font.Font(None, 24)
        f_enemigo = pygame.font.Font(None, 18)

        def texto_sinergia(p, tecla):
            s = sinergias.get(p['datos'].get('apoyo'))
            if not s or p['vida'] <= 0: return None
            resto = s['enfriamiento'] - (pygame.time.get_ticks() - p['ultimo_sin'])
            if resto <= 0: return tecla + ' ' + s['nombre'] + ' LISTO', (0, 110, 0)
            return tecla + ' ' + s['nombre'] + ' ' + str(int(resto / 1000) + 1) + 's', (90, 90, 90)

        def dibujar_slot(p, slot, x, y, radio, ancho_barra, alto_barra, fuente, grande=False, extra=None):
            centro = (x + radio, y + radio)
            proporcion = max(0, p['vida']) / max(1, p['max_vida'])
            retrato = cargar_retrato(p['nombre'], radio * 2, 'Pain' if 0 < proporcion < 0.3 else 'Normal')
            if retrato: ventana.blit(retrato, (x, y))
            else: pygame.draw.circle(ventana, 'white', centro, radio)
            pygame.draw.circle(ventana, 'black', centro, radio, 2)
            alto_texto = fuente.size('A')[1]
            ventana.blit(fuente.render(str(slot + 1), True, 'black'), (x + radio * 2 - 3, y + radio * 2 - alto_texto + 2))
            barra_r = pygame.Rect(x + radio * 2 + 8, centro[1] - alto_barra // 2, ancho_barra, alto_barra)
            pygame.draw.rect(ventana, 'white', barra_r)
            relleno = barra_r.inflate(-4, -4)
            relleno.width = int(relleno.width * proporcion)
            pygame.draw.rect(ventana, (130, 0, 20) if p['vida'] > 0 else (110, 110, 110), relleno)
            pygame.draw.rect(ventana, 'black', barra_r, 2)
            base = barra_r.bottom + 2
            if grande:
                energia_r = pygame.Rect(barra_r.x, base, int(ancho_barra * 0.6), 8)
                pygame.draw.rect(ventana, (110, 110, 110), energia_r)
                pygame.draw.rect(ventana, (0, 160, 230), (energia_r.x, energia_r.y, int(energia_r.width * p['energia'] / ENERGIA_MAX), energia_r.height))
                pygame.draw.rect(ventana, 'black', energia_r, 1)
                base = energia_r.bottom + 2
                texto = str(int(p['vida'])) + '/' + str(p['max_vida'])
                ventana.blit(fuente.render(texto, True, 'black'), (barra_r.right - fuente.size(texto)[0] - 2, base))
            nombre = p['nombre'].replace('_', ' ').title() + ('' if p['vida'] > 0 else '  (KO)')
            ventana.blit(fuente.render(nombre, True, 'black'), (barra_r.x + 2, base))
            if extra: ventana.blit(fuente.render(extra[0], True, extra[1]), (barra_r.x + 2, base + alto_texto))

        def dibujar_hud(equipo, activo):
            y = 12; k = 0
            for i, p in enumerate(equipo):
                if i == activo: continue
                dibujar_slot(p, i, 14, y, 12, 105, 14, f_hud, False, texto_sinergia(p, 'ZX'[k]))
                y += 48; k += 1
            dibujar_slot(equipo[activo], activo, 14, y + 2, 28, 210, 32, f_hud_g, True)

        def dibujar_habilidades(j):
            claves = j['datos'].get('habilidades') or []
            ahora = pygame.time.get_ticks()
            for i, (cx, cy, r, tecla) in enumerate(((W - 50, H - 44, 28, 'SHIFT'), (W - 106, H - 34, 20, 'R'))):
                if i >= len(claves) or claves[i] not in habilidades: continue
                h = habilidades[claves[i]]
                resto = max(0, h['enfriamiento'] * j['cd_hab_mult'] * mult_buff(j, 'cooldown') - (ahora - j['ultimo_hab'][i]))
                pygame.draw.circle(ventana, 'white' if resto <= 0 else (150, 150, 150), (cx, cy), r)
                pygame.draw.circle(ventana, COLORES_HAB.get(h['tipo'], 'black'), (cx, cy), r, 3)
                texto = f_hud.render(tecla if resto <= 0 else format(resto / 1000, '.1f'), True, 'black')
                ventana.blit(texto, texto.get_rect(center=(cx, cy)))
                nombre = f_hud.render(h['nombre'], True, 'black')
                ventana.blit(nombre, nombre.get_rect(center=(cx, cy - r - 8)))

        def dibujar_barra_jefe(nivel):
            b = nivel['jefe']
            if not b: return
            r = pygame.Rect(W - 320, 14, 300, 20)
            pygame.draw.rect(ventana, 'white', r)
            relleno = r.inflate(-4, -4)
            relleno.width = int(relleno.width * max(0, b['vida']) / max(1, b['max_vida']))
            pygame.draw.rect(ventana, (130, 0, 20), relleno)
            pygame.draw.rect(ventana, 'black', r, 2)
            ventana.blit(f_hud_g.render('JEFE  ' + str(b['tipo']).title(), True, 'black'), (r.x, r.bottom + 3))

        def dibujar_mira(j):
            if not j['aim']: return
            mx, my = pygame.mouse.get_pos()
            pygame.draw.circle(ventana, (200, 0, 0), (mx, my), 9, 2)
            for ax, ay in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                pygame.draw.line(ventana, (200, 0, 0), (mx + ax * 5, my + ay * 5), (mx + ax * 14, my + ay * 14), 2)

        def dibujar_efectos(nivel, cx, cy):
            ahora = pygame.time.get_ticks()
            for ef in nivel['efectos']:
                t = (ahora - ef['inicio']) / ef['duracion']
                px, py = round(ef['x'] - cx), round(ef['y'] - cy)
                if ef.get('linea'): pygame.draw.line(ventana, ef['color'], (px, py - 300), (px, py), 5)
                pygame.draw.circle(ventana, ef['color'], (px, py), max(2, int(ef['radio'] * min(1.0, 0.3 + t))), 4)

        def dibujar_estados(j, cx, cy):
            ahora = pygame.time.get_ticks()
            centro = (j['rect'].centerx - cx, j['rect'].centery - cy)
            radio = max(j['hitbox']) // 2 + 12
            if ahora < j['escudo_hasta']: pygame.draw.circle(ventana, 'white', centro, radio + 4, 4)
            if j['buff'] and ahora < j['buff']['hasta']: pygame.draw.circle(ventana, (255, 200, 40), centro, radio, 2)
            if ahora < j['inmovil_hasta']: ventana.blit(f_hud_g.render('Zz', True, 'black'), (centro[0] + radio // 2, centro[1] - radio - 14))

        def dibujar_objetos(nivel, j, equipo, activo):
            cx, cy = camara(j)
            ventana.fill('black')
            dibujar_rect(ESC, cx, cy, 'white')
            paredes = [pygame.Rect(0,0,ESC.width,PARED), pygame.Rect(0,ESC.bottom-PARED,ESC.width,PARED), pygame.Rect(0,0,PARED,ESC.height), pygame.Rect(ESC.right-PARED,0,PARED,ESC.height)]
            for pared in paredes: dibujar_rect(pared,cx,cy,'black')
            for piedra in nivel['piedras']: dibujar_rect(piedra,cx,cy,(100,100,100),'ellipse')
            for piedra_verde in nivel['verdes']: dibujar_rect(piedra_verde['rect'],cx,cy,(0,220,80),'ellipse')
            for puerta in nivel['puertas']: dibujar_rect(puerta,cx,cy,(60,180,80) if j['llave'] else (120,70,30))
            for proyectil in nivel['proyectiles_enemigos']:
                pygame.draw.circle(ventana, (255,50,0) if proyectil['jefe'] else (255,150,0), (round(proyectil['x']-cx),round(proyectil['y']-cy)), 9 if proyectil['jefe'] else 8)
            for proyectil in nivel['proyectiles_pokemon']:
                try: radio = max(2, int(float(proyectil['datos'].get('area', 8))))
                except (TypeError, ValueError): radio = 8
                pygame.draw.circle(ventana, (80,180,255), (round(proyectil['x']-cx),round(proyectil['y']-cy)), radio)
            dibujar_efectos(nivel, cx, cy)
            dibujar_jugador(j,cx,cy)
            dibujar_estados(j, cx, cy)
            for e in nivel['enemigos']:
                dibujar_rect(e['rect'],cx,cy,e['color'])
                barra((e['rect'].x-cx,e['rect'].y-cy-9,e['rect'].width,5),e['vida'],e['max_vida'])
                ventana.blit(f_enemigo.render(e['tipo'],True,'black'),(e['rect'].x-cx,e['rect'].y-cy+15))
            if nivel['jefe']:
                b = nivel['jefe']; dibujar_rect(b['rect'],cx,cy,b.get('color',(255,140,0))); barra((b['rect'].x-cx,b['rect'].y-cy-12,b['rect'].width,8),b['vida'],b['max_vida'],8)
            if nivel['llave']: dibujar_rect(nivel['llave'],cx,cy,'yellow')
            if nivel['completado']:
                r = pygame.Rect(260, 210, 480, 170)
                pygame.draw.rect(ventana, (25,25,25), r)
                pygame.draw.rect(ventana, (80,220,100), r, 3)
                f = pygame.font.Font(None, 36)
                ventana.blit(f.render('¡NIVEL COMPLETADO!', True, 'white'), (350,245))
                texto_nivel = 'Ve a buscar la llave' if not j['llave'] else 'Ve a una puerta para continuar'
                ventana.blit(pygame.font.Font(None, 24).render(texto_nivel, True, (220,220,220)), (335,295))
            dibujar_hud(equipo, activo)
            dibujar_habilidades(j)
            dibujar_barra_jefe(nivel)
            dibujar_mira(j)
            pygame.display.flip()

        equipo = [crear_jugador(n, ESC.center) for n in armar_equipo(pokemon)]
        activo = 0; j = equipo[activo]; ultimo_cambio = -10000; mouse_activo = False
        nivel_numero = 0
        reloj = pygame.time.Clock()
        while True:
            reubicar_equipo(equipo); nivel = crear_nivel(nivel_numero)
            reiniciar_nivel = False
            while True:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT: return 'salir', j['nombre']
                    if e.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN): mouse_activo = True
                    if e.type == pygame.KEYDOWN:
                        if e.key == pygame.K_ESCAPE:
                            if confirmar_salida(): return 'salir', j['nombre']
                        if e.key == pygame.K_F1: return 'debug', j['nombre']
                        if e.key == pygame.K_F2:
                            nuevo_nivel = menu_niveles(nivel_numero)
                            if nuevo_nivel == 'salir': return 'salir', j['nombre']
                            nivel_numero = nuevo_nivel
                            reiniciar_nivel = True
                            break
                        if e.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                            nuevo = e.key - pygame.K_1
                            if nuevo < len(equipo) and nuevo != activo and equipo[nuevo]['vida'] > 0 and pygame.time.get_ticks() - ultimo_cambio >= CAMBIO_CD:
                                activo = cambiar_activo(equipo, activo, nuevo, nivel['piedras']); j = equipo[activo]; ultimo_cambio = pygame.time.get_ticks()
                        if e.key in (pygame.K_LSHIFT, pygame.K_RSHIFT): usar_habilidad(j, 0, nivel)
                        if e.key == pygame.K_r: usar_habilidad(j, 1, nivel)
                        if e.key == pygame.K_z: usar_sinergia(equipo, activo, 0, nivel)
                        if e.key == pygame.K_x: usar_sinergia(equipo, activo, 1, nivel)
                if reiniciar_nivel:
                    break
                if mouse_activo:
                    ccx, ccy = camara(j); mx, my = pygame.mouse.get_pos()
                    ax, ay = mx + ccx - j['rect'].centerx, my + ccy - j['rect'].centery
                    if math.hypot(ax, ay) > 4:
                        n = math.hypot(ax, ay); j['aim'] = (ax / n, ay / n); j['direccion'] = direccion_8(ax, ay)
                teclas = pygame.key.get_pressed(); botones = pygame.mouse.get_pressed()
                if botones[0] or teclas[pygame.K_q]: atacar_proyectil(j, nivel['proyectiles_pokemon'])
                if botones[2] or teclas[pygame.K_e]: atacar_cuerpo(j, objetivos_nivel(nivel))
                j['bonus_equipo'] = 1.0 + sum(p['sinergia'] for i, p in enumerate(equipo) if i != activo and p['vida'] > 0)
                resultado = actualizar_nivel(nivel, j)
                dibujar_objetos(nivel, j, equipo, activo)
                if resultado == 'siguiente': nivel_numero += 1; break
                if resultado == 'muerte':
                    vivos = [i for i, p in enumerate(equipo) if p['vida'] > 0]
                    if not vivos: return 'juego_terminado', j['nombre']
                    activo = cambiar_activo(equipo, activo, vivos[0], nivel['piedras']); j = equipo[activo]
                reloj.tick(60)

    def ajustes(volumen):
        reloj_ajustes = pygame.time.Clock()
        f_titulo = pygame.font.Font(None, 48)
        f_texto = pygame.font.Font(None, 36)
        while True:
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return None
                if e.type == pygame.KEYDOWN:
                    if e.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                        return volumen
                    if e.key in (pygame.K_a, pygame.K_LEFT):
                        volumen = max(10, volumen - 10)
                    if e.key in (pygame.K_d, pygame.K_RIGHT):
                        volumen = min(100, volumen + 10)

            ventana.fill('black')
            titulo = f_titulo.render('AJUSTES', True, 'white')
            ventana.blit(titulo, titulo.get_rect(center=(W // 2, 120)))

            fila = pygame.Rect(0, 0, 420, 70)
            fila.center = (W // 2, H // 2)
            pygame.draw.rect(ventana, (0, 120, 0), fila)
            ventana.blit(f_texto.render('Sonidos', True, 'white'), (fila.x + 20, fila.centery - 12))
            valor = f_texto.render('< ' + str(volumen) + ' >', True, 'white')
            ventana.blit(valor, valor.get_rect(midright=(fila.right - 20, fila.centery)))
            dibujar_esquinas(ventana, fila)

            for i in range(10):
                color = (255, 255, 255) if i < volumen // 10 else (70, 70, 70)
                pygame.draw.rect(ventana, color, (fila.x + i * 42, fila.bottom + 25, 36, 12))

            ayuda = fuente.render('A / D: cambiar volumen (10 a 100)    ESC: volver', True, (200, 200, 200))
            ventana.blit(ayuda, ayuda.get_rect(center=(W // 2, H - 60)))
            pygame.display.flip(); reloj_ajustes.tick(60)

    pokemon = 'pikachu' if 'pikachu' in pokemones else next(iter(pokemones))
    volumen = 50
    orden = ['jugar', 'ajustes', 'salir']
    textos = {'jugar': 'Jugar', 'ajustes': 'Ajustes', 'salir': 'Salir'}
    colores = {'jugar': (200, 0, 0), 'ajustes': (0, 200, 0), 'salir': (0, 0, 200)}
    bw, bh, sep = 200, 60, 30
    alto_total = len(orden) * bh + (len(orden) - 1) * sep
    logo_ancho, logo_alto, logo_sep = 360, 160, 40
    y_logo = (H - (logo_alto + logo_sep + alto_total)) // 2
    y0 = y_logo + logo_alto + logo_sep
    logo_rect = pygame.Rect((W - logo_ancho) // 2, y_logo, logo_ancho, logo_alto)
    botones = {nombre: pygame.Rect((W - bw) // 2, y0 + i * (bh + sep), bw, bh) for i, nombre in enumerate(orden)}
    seleccion = 0
    reloj = pygame.time.Clock()

    while True:
        activar = None
        for e in pygame.event.get():
            if e.type == pygame.QUIT or (e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE):
                pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN and e.key == pygame.K_F1:
                resultado_debug, pokemon_seleccionado = debug_menu(pokemon)
                if resultado_debug == 'salir': pygame.quit(); sys.exit()
                if pokemon_seleccionado in pokemones: pokemon = pokemon_seleccionado
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_w:
                    seleccion = (seleccion - 1) % len(orden)
                elif e.key == pygame.K_s:
                    seleccion = (seleccion + 1) % len(orden)
                elif e.key in (pygame.K_RETURN, pygame.K_e):
                    activar = orden[seleccion]
            if e.type == pygame.MOUSEMOTION:
                for i, nombre in enumerate(orden):
                    if botones[nombre].collidepoint(e.pos):
                        seleccion = i
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for i, nombre in enumerate(orden):
                    if botones[nombre].collidepoint(e.pos):
                        seleccion = i
                        activar = nombre

        if activar == 'jugar':
            while True:
                resultado, seleccionado = jugar(pokemon)
                if resultado == 'salir': pygame.quit(); sys.exit()
                if resultado == 'debug':
                    resultado_debug, pokemon_seleccionado = debug_menu(pokemon)
                    if resultado_debug == 'salir': pygame.quit(); sys.exit()
                    if pokemon_seleccionado in pokemones: pokemon = pokemon_seleccionado
                    continue
                break
        elif activar == 'ajustes':
            resultado_ajustes = ajustes(volumen)
            if resultado_ajustes is None: pygame.quit(); sys.exit()
            volumen = resultado_ajustes
            try: pygame.mixer.music.set_volume(volumen / 100)
            except pygame.error: pass
        elif activar == 'salir':
            pygame.quit(); sys.exit()

        ventana.fill('black')
        # rectangulo del logo (no es un boton); despues se puede dibujar la imagen del logo aca
        pygame.draw.rect(ventana, (30, 30, 30), logo_rect)
        pygame.draw.rect(ventana, (120, 120, 120), logo_rect, 2)
        for i, nombre in enumerate(orden):
            pygame.draw.rect(ventana, colores[nombre], botones[nombre])
            texto = fuente.render(textos[nombre], True, 'white')
            ventana.blit(texto, texto.get_rect(center=botones[nombre].center))
            if i == seleccion:
                dibujar_esquinas(ventana, botones[nombre])
        ventana.blit(fuente.render('F1: Menu debug', True, 'white'), (700, 20))
        ventana.blit(fuente.render('Pokemon: ' + pokemon, True, 'white'), (700, 45))
        pygame.display.flip(); reloj.tick(60)

if __name__ == '__main__':
    main()